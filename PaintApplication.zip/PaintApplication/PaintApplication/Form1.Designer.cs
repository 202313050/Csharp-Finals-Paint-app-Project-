﻿namespace PaintApplication
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            panel1 = new Panel();
            impBtn = new Button();
            Savebtn = new Button();
            Minimizebtn = new Button();
            Maximizebtn = new Button();
            Exitbtn = new Button();
            tableLayoutPanel1 = new TableLayoutPanel();
            ColorPb = new PictureBox();
            BtnColor20 = new PictureBox();
            BtnColor19 = new PictureBox();
            BtnColor10 = new PictureBox();
            BtnColor9 = new PictureBox();
            BtnColor18 = new PictureBox();
            BtnColor17 = new PictureBox();
            BtnColor8 = new PictureBox();
            BtnColor7 = new PictureBox();
            BtnColor16 = new PictureBox();
            BtnColor15 = new PictureBox();
            BtnColor14 = new PictureBox();
            BtnColor13 = new PictureBox();
            BtnColor12 = new PictureBox();
            BtnColor6 = new PictureBox();
            BtnColor5 = new PictureBox();
            BtnColor4 = new PictureBox();
            BtnColor3 = new PictureBox();
            BtnColor2 = new PictureBox();
            BtnColor11 = new PictureBox();
            BtnColor1 = new PictureBox();
            button15 = new Button();
            button21 = new Button();
            BtnRectangle = new Button();
            BtnLine = new Button();
            BtnEraser = new Button();
            BtnPen = new Button();
            BtnColorDropper = new Button();
            BtnFillColor = new Button();
            BtnCircle = new Button();
            PnlPenWidth = new Panel();
            BtnPenWidth1 = new Button();
            Largebtn = new Button();
            button9 = new Button();
            BtnPenWidth2 = new Button();
            BtnColorSet = new Button();
            Tools = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            PnlMain = new Panel();
            Pic = new PictureBox();
            panel1.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ColorPb).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor20).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor19).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor18).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor17).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor16).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor1).BeginInit();
            PnlPenWidth.SuspendLayout();
            PnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)Pic).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.AppWorkspace;
            panel1.Controls.Add(impBtn);
            panel1.Controls.Add(Savebtn);
            panel1.Controls.Add(Minimizebtn);
            panel1.Controls.Add(Maximizebtn);
            panel1.Controls.Add(Exitbtn);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(800, 41);
            panel1.TabIndex = 0;
            // 
            // impBtn
            // 
            impBtn.BackgroundImage = (Image)resources.GetObject("impBtn.BackgroundImage");
            impBtn.BackgroundImageLayout = ImageLayout.Zoom;
            impBtn.FlatStyle = FlatStyle.Flat;
            impBtn.ForeColor = SystemColors.AppWorkspace;
            impBtn.Location = new Point(41, 8);
            impBtn.Margin = new Padding(0);
            impBtn.Name = "impBtn";
            impBtn.Size = new Size(20, 25);
            impBtn.TabIndex = 5;
            impBtn.UseVisualStyleBackColor = true;
            impBtn.Click += impBtn_Click;
            // 
            // Savebtn
            // 
            Savebtn.BackgroundImage = (Image)resources.GetObject("Savebtn.BackgroundImage");
            Savebtn.BackgroundImageLayout = ImageLayout.Zoom;
            Savebtn.FlatStyle = FlatStyle.Flat;
            Savebtn.ForeColor = SystemColors.AppWorkspace;
            Savebtn.Location = new Point(12, 7);
            Savebtn.Margin = new Padding(0);
            Savebtn.Name = "Savebtn";
            Savebtn.Size = new Size(20, 25);
            Savebtn.TabIndex = 4;
            Savebtn.UseVisualStyleBackColor = true;
            Savebtn.Click += Savebtn_Click;
            // 
            // Minimizebtn
            // 
            Minimizebtn.BackgroundImage = (Image)resources.GetObject("Minimizebtn.BackgroundImage");
            Minimizebtn.BackgroundImageLayout = ImageLayout.Zoom;
            Minimizebtn.Dock = DockStyle.Right;
            Minimizebtn.FlatStyle = FlatStyle.Flat;
            Minimizebtn.ForeColor = SystemColors.AppWorkspace;
            Minimizebtn.Location = new Point(736, 0);
            Minimizebtn.Margin = new Padding(0);
            Minimizebtn.Name = "Minimizebtn";
            Minimizebtn.Padding = new Padding(0, 0, 10, 0);
            Minimizebtn.Size = new Size(24, 41);
            Minimizebtn.TabIndex = 2;
            Minimizebtn.UseVisualStyleBackColor = true;
            Minimizebtn.Click += Minimizebtn_Click;
            // 
            // Maximizebtn
            // 
            Maximizebtn.BackgroundImage = (Image)resources.GetObject("Maximizebtn.BackgroundImage");
            Maximizebtn.BackgroundImageLayout = ImageLayout.Zoom;
            Maximizebtn.Dock = DockStyle.Right;
            Maximizebtn.FlatStyle = FlatStyle.Flat;
            Maximizebtn.ForeColor = SystemColors.AppWorkspace;
            Maximizebtn.Location = new Point(760, 0);
            Maximizebtn.Margin = new Padding(0);
            Maximizebtn.Name = "Maximizebtn";
            Maximizebtn.Padding = new Padding(5, 10, 5, 5);
            Maximizebtn.Size = new Size(20, 41);
            Maximizebtn.TabIndex = 1;
            Maximizebtn.UseVisualStyleBackColor = true;
            Maximizebtn.Click += Maximizebtn_Click;
            // 
            // Exitbtn
            // 
            Exitbtn.BackgroundImage = (Image)resources.GetObject("Exitbtn.BackgroundImage");
            Exitbtn.BackgroundImageLayout = ImageLayout.Zoom;
            Exitbtn.Dock = DockStyle.Right;
            Exitbtn.FlatStyle = FlatStyle.Flat;
            Exitbtn.ForeColor = SystemColors.AppWorkspace;
            Exitbtn.Location = new Point(780, 0);
            Exitbtn.Margin = new Padding(0);
            Exitbtn.Name = "Exitbtn";
            Exitbtn.Size = new Size(20, 41);
            Exitbtn.TabIndex = 0;
            Exitbtn.UseVisualStyleBackColor = true;
            Exitbtn.Click += button1_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 25;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 5.70946169F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 5.70946169F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 5.70946169F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 5.70946169F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 5.70946169F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 5.70946169F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 5.70946169F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 5.70946169F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 2.44691181F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 7.340736F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 2.44691181F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 5.70946169F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 2.94975257F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 2.94975257F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 2.94975257F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 2.94975257F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 2.94975257F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 2.94975257F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 2.94975257F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 2.94975257F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 2.94975257F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 2.94975257F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 6.882756F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 10F));
            tableLayoutPanel1.Controls.Add(ColorPb, 12, 1);
            tableLayoutPanel1.Controls.Add(BtnColor20, 22, 2);
            tableLayoutPanel1.Controls.Add(BtnColor19, 21, 2);
            tableLayoutPanel1.Controls.Add(BtnColor10, 22, 1);
            tableLayoutPanel1.Controls.Add(BtnColor9, 21, 1);
            tableLayoutPanel1.Controls.Add(BtnColor18, 20, 2);
            tableLayoutPanel1.Controls.Add(BtnColor17, 19, 2);
            tableLayoutPanel1.Controls.Add(BtnColor8, 20, 1);
            tableLayoutPanel1.Controls.Add(BtnColor7, 19, 1);
            tableLayoutPanel1.Controls.Add(BtnColor16, 18, 2);
            tableLayoutPanel1.Controls.Add(BtnColor15, 17, 2);
            tableLayoutPanel1.Controls.Add(BtnColor14, 16, 2);
            tableLayoutPanel1.Controls.Add(BtnColor13, 15, 2);
            tableLayoutPanel1.Controls.Add(BtnColor12, 14, 2);
            tableLayoutPanel1.Controls.Add(BtnColor6, 18, 1);
            tableLayoutPanel1.Controls.Add(BtnColor5, 17, 1);
            tableLayoutPanel1.Controls.Add(BtnColor4, 16, 1);
            tableLayoutPanel1.Controls.Add(BtnColor3, 15, 1);
            tableLayoutPanel1.Controls.Add(BtnColor2, 14, 1);
            tableLayoutPanel1.Controls.Add(BtnColor11, 13, 2);
            tableLayoutPanel1.Controls.Add(BtnColor1, 13, 1);
            tableLayoutPanel1.Controls.Add(button15, 1, 0);
            tableLayoutPanel1.Controls.Add(button21, 0, 0);
            tableLayoutPanel1.Controls.Add(BtnRectangle, 7, 1);
            tableLayoutPanel1.Controls.Add(BtnLine, 6, 1);
            tableLayoutPanel1.Controls.Add(BtnEraser, 2, 1);
            tableLayoutPanel1.Controls.Add(BtnPen, 1, 1);
            tableLayoutPanel1.Controls.Add(BtnColorDropper, 4, 1);
            tableLayoutPanel1.Controls.Add(BtnFillColor, 3, 1);
            tableLayoutPanel1.Controls.Add(BtnCircle, 8, 1);
            tableLayoutPanel1.Controls.Add(PnlPenWidth, 10, 1);
            tableLayoutPanel1.Controls.Add(BtnColorSet, 23, 1);
            tableLayoutPanel1.Controls.Add(Tools, 1, 3);
            tableLayoutPanel1.Controls.Add(label1, 6, 3);
            tableLayoutPanel1.Controls.Add(label2, 10, 3);
            tableLayoutPanel1.Controls.Add(label3, 14, 3);
            tableLayoutPanel1.Dock = DockStyle.Top;
            tableLayoutPanel1.Location = new Point(0, 41);
            tableLayoutPanel1.Margin = new Padding(0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 4;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 15F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 25F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Size = new Size(800, 100);
            tableLayoutPanel1.TabIndex = 1;
            // 
            // ColorPb
            // 
            ColorPb.BackColor = SystemColors.ActiveCaptionText;
            ColorPb.Location = new Point(460, 18);
            ColorPb.Name = "ColorPb";
            tableLayoutPanel1.SetRowSpan(ColorPb, 2);
            ColorPb.Size = new Size(38, 54);
            ColorPb.TabIndex = 29;
            ColorPb.TabStop = false;
            // 
            // BtnColor20
            // 
            BtnColor20.BackColor = Color.FromArgb(128, 64, 0);
            BtnColor20.Location = new Point(711, 48);
            BtnColor20.Name = "BtnColor20";
            BtnColor20.Size = new Size(17, 24);
            BtnColor20.TabIndex = 28;
            BtnColor20.TabStop = false;
            BtnColor20.Click += btnColor_Click;
            // 
            // BtnColor19
            // 
            BtnColor19.BackColor = SystemColors.ActiveCaptionText;
            BtnColor19.Location = new Point(688, 48);
            BtnColor19.Name = "BtnColor19";
            BtnColor19.Size = new Size(17, 24);
            BtnColor19.TabIndex = 28;
            BtnColor19.TabStop = false;
            BtnColor19.Click += btnColor_Click;
            // 
            // BtnColor10
            // 
            BtnColor10.BackColor = Color.FromArgb(192, 64, 0);
            BtnColor10.Location = new Point(711, 18);
            BtnColor10.Name = "BtnColor10";
            BtnColor10.Size = new Size(17, 24);
            BtnColor10.TabIndex = 28;
            BtnColor10.TabStop = false;
            BtnColor10.Click += btnColor_Click;
            // 
            // BtnColor9
            // 
            BtnColor9.BackColor = Color.White;
            BtnColor9.Location = new Point(688, 18);
            BtnColor9.Name = "BtnColor9";
            BtnColor9.Size = new Size(17, 24);
            BtnColor9.TabIndex = 28;
            BtnColor9.TabStop = false;
            BtnColor9.Click += btnColor_Click;
            // 
            // BtnColor18
            // 
            BtnColor18.BackColor = Color.FromArgb(255, 128, 255);
            BtnColor18.Location = new Point(665, 48);
            BtnColor18.Name = "BtnColor18";
            BtnColor18.Size = new Size(17, 24);
            BtnColor18.TabIndex = 28;
            BtnColor18.TabStop = false;
            BtnColor18.Click += btnColor_Click;
            // 
            // BtnColor17
            // 
            BtnColor17.BackColor = Color.FromArgb(128, 128, 255);
            BtnColor17.Location = new Point(642, 48);
            BtnColor17.Name = "BtnColor17";
            BtnColor17.Size = new Size(17, 24);
            BtnColor17.TabIndex = 28;
            BtnColor17.TabStop = false;
            BtnColor17.Click += btnColor_Click;
            // 
            // BtnColor8
            // 
            BtnColor8.BackColor = Color.Fuchsia;
            BtnColor8.Location = new Point(665, 18);
            BtnColor8.Name = "BtnColor8";
            BtnColor8.Size = new Size(17, 24);
            BtnColor8.TabIndex = 28;
            BtnColor8.TabStop = false;
            BtnColor8.Click += btnColor_Click;
            // 
            // BtnColor7
            // 
            BtnColor7.BackColor = Color.Blue;
            BtnColor7.Location = new Point(642, 18);
            BtnColor7.Name = "BtnColor7";
            BtnColor7.Size = new Size(17, 24);
            BtnColor7.TabIndex = 28;
            BtnColor7.TabStop = false;
            BtnColor7.Click += btnColor_Click;
            // 
            // BtnColor16
            // 
            BtnColor16.BackColor = Color.FromArgb(192, 255, 255);
            BtnColor16.Location = new Point(619, 48);
            BtnColor16.Name = "BtnColor16";
            BtnColor16.Size = new Size(17, 24);
            BtnColor16.TabIndex = 28;
            BtnColor16.TabStop = false;
            BtnColor16.Click += btnColor_Click;
            // 
            // BtnColor15
            // 
            BtnColor15.BackColor = Color.FromArgb(128, 255, 128);
            BtnColor15.Location = new Point(596, 48);
            BtnColor15.Name = "BtnColor15";
            BtnColor15.Size = new Size(17, 24);
            BtnColor15.TabIndex = 28;
            BtnColor15.TabStop = false;
            BtnColor15.Click += btnColor_Click;
            // 
            // BtnColor14
            // 
            BtnColor14.BackColor = Color.FromArgb(255, 128, 128);
            BtnColor14.Location = new Point(573, 48);
            BtnColor14.Name = "BtnColor14";
            BtnColor14.Size = new Size(17, 24);
            BtnColor14.TabIndex = 28;
            BtnColor14.TabStop = false;
            BtnColor14.Click += btnColor_Click;
            // 
            // BtnColor13
            // 
            BtnColor13.BackColor = Color.FromArgb(255, 255, 128);
            BtnColor13.Location = new Point(550, 48);
            BtnColor13.Name = "BtnColor13";
            BtnColor13.Size = new Size(17, 24);
            BtnColor13.TabIndex = 28;
            BtnColor13.TabStop = false;
            BtnColor13.Click += btnColor_Click;
            // 
            // BtnColor12
            // 
            BtnColor12.BackColor = Color.FromArgb(255, 192, 128);
            BtnColor12.Location = new Point(527, 48);
            BtnColor12.Name = "BtnColor12";
            BtnColor12.Size = new Size(17, 24);
            BtnColor12.TabIndex = 28;
            BtnColor12.TabStop = false;
            BtnColor12.Click += btnColor_Click;
            // 
            // BtnColor6
            // 
            BtnColor6.BackColor = Color.Cyan;
            BtnColor6.Location = new Point(619, 18);
            BtnColor6.Name = "BtnColor6";
            BtnColor6.Size = new Size(17, 24);
            BtnColor6.TabIndex = 28;
            BtnColor6.TabStop = false;
            BtnColor6.Click += btnColor_Click;
            // 
            // BtnColor5
            // 
            BtnColor5.BackColor = Color.Lime;
            BtnColor5.Location = new Point(596, 18);
            BtnColor5.Name = "BtnColor5";
            BtnColor5.Size = new Size(17, 24);
            BtnColor5.TabIndex = 28;
            BtnColor5.TabStop = false;
            BtnColor5.Click += btnColor_Click;
            // 
            // BtnColor4
            // 
            BtnColor4.BackColor = Color.Yellow;
            BtnColor4.Location = new Point(573, 18);
            BtnColor4.Name = "BtnColor4";
            BtnColor4.Size = new Size(17, 24);
            BtnColor4.TabIndex = 28;
            BtnColor4.TabStop = false;
            BtnColor4.Click += btnColor_Click;
            // 
            // BtnColor3
            // 
            BtnColor3.BackColor = Color.Red;
            BtnColor3.Location = new Point(550, 18);
            BtnColor3.Name = "BtnColor3";
            BtnColor3.Size = new Size(17, 24);
            BtnColor3.TabIndex = 28;
            BtnColor3.TabStop = false;
            BtnColor3.Click += btnColor_Click;
            // 
            // BtnColor2
            // 
            BtnColor2.BackColor = Color.FromArgb(255, 128, 0);
            BtnColor2.Location = new Point(527, 18);
            BtnColor2.Name = "BtnColor2";
            BtnColor2.Size = new Size(17, 24);
            BtnColor2.TabIndex = 28;
            BtnColor2.TabStop = false;
            BtnColor2.Click += btnColor_Click;
            // 
            // BtnColor11
            // 
            BtnColor11.BackColor = SystemColors.ActiveBorder;
            BtnColor11.Location = new Point(504, 48);
            BtnColor11.Name = "BtnColor11";
            BtnColor11.Size = new Size(17, 24);
            BtnColor11.TabIndex = 28;
            BtnColor11.TabStop = false;
            BtnColor11.Click += btnColor_Click;
            // 
            // BtnColor1
            // 
            BtnColor1.BackColor = Color.Gray;
            BtnColor1.Location = new Point(504, 18);
            BtnColor1.Name = "BtnColor1";
            BtnColor1.Size = new Size(17, 24);
            BtnColor1.TabIndex = 27;
            BtnColor1.TabStop = false;
            BtnColor1.Click += btnColor_Click;
            // 
            // button15
            // 
            button15.BackgroundImage = (Image)resources.GetObject("button15.BackgroundImage");
            button15.BackgroundImageLayout = ImageLayout.Zoom;
            button15.FlatStyle = FlatStyle.Flat;
            button15.ForeColor = SystemColors.Control;
            button15.Location = new Point(15, 10);
            button15.Margin = new Padding(5, 10, 5, 5);
            button15.Name = "button15";
            button15.Size = new Size(13, 1);
            button15.TabIndex = 14;
            button15.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            button21.BackgroundImage = (Image)resources.GetObject("button21.BackgroundImage");
            button21.BackgroundImageLayout = ImageLayout.Zoom;
            button21.FlatStyle = FlatStyle.Flat;
            button21.ForeColor = SystemColors.Control;
            button21.Location = new Point(5, 10);
            button21.Margin = new Padding(5, 10, 5, 5);
            button21.Name = "button21";
            button21.Size = new Size(1, 1);
            button21.TabIndex = 13;
            button21.UseVisualStyleBackColor = true;
            // 
            // BtnRectangle
            // 
            BtnRectangle.BackgroundImage = (Image)resources.GetObject("BtnRectangle.BackgroundImage");
            BtnRectangle.BackgroundImageLayout = ImageLayout.Zoom;
            BtnRectangle.FlatStyle = FlatStyle.Flat;
            BtnRectangle.ForeColor = SystemColors.Control;
            BtnRectangle.Location = new Point(279, 25);
            BtnRectangle.Margin = new Padding(5, 10, 5, 5);
            BtnRectangle.Name = "BtnRectangle";
            tableLayoutPanel1.SetRowSpan(BtnRectangle, 2);
            BtnRectangle.Size = new Size(30, 40);
            BtnRectangle.TabIndex = 7;
            BtnRectangle.Tag = "6";
            BtnRectangle.UseVisualStyleBackColor = true;
            BtnRectangle.Click += Btn_Click;
            // 
            // BtnLine
            // 
            BtnLine.BackgroundImage = (Image)resources.GetObject("BtnLine.BackgroundImage");
            BtnLine.BackgroundImageLayout = ImageLayout.Zoom;
            BtnLine.FlatStyle = FlatStyle.Flat;
            BtnLine.ForeColor = SystemColors.Control;
            BtnLine.Location = new Point(235, 25);
            BtnLine.Margin = new Padding(5, 10, 5, 5);
            BtnLine.Name = "BtnLine";
            tableLayoutPanel1.SetRowSpan(BtnLine, 2);
            BtnLine.Size = new Size(30, 40);
            BtnLine.TabIndex = 7;
            BtnLine.Tag = "5";
            BtnLine.UseVisualStyleBackColor = true;
            BtnLine.Click += Btn_Click;
            // 
            // BtnEraser
            // 
            BtnEraser.BackgroundImage = (Image)resources.GetObject("BtnEraser.BackgroundImage");
            BtnEraser.BackgroundImageLayout = ImageLayout.Zoom;
            BtnEraser.FlatStyle = FlatStyle.Flat;
            BtnEraser.ForeColor = SystemColors.Control;
            BtnEraser.Location = new Point(59, 25);
            BtnEraser.Margin = new Padding(5, 10, 5, 5);
            BtnEraser.Name = "BtnEraser";
            tableLayoutPanel1.SetRowSpan(BtnEraser, 2);
            BtnEraser.Size = new Size(30, 40);
            BtnEraser.TabIndex = 6;
            BtnEraser.Tag = "2";
            BtnEraser.UseVisualStyleBackColor = true;
            BtnEraser.Click += Btn_Click;
            // 
            // BtnPen
            // 
            BtnPen.BackgroundImage = (Image)resources.GetObject("BtnPen.BackgroundImage");
            BtnPen.BackgroundImageLayout = ImageLayout.Zoom;
            BtnPen.FlatStyle = FlatStyle.Flat;
            BtnPen.ForeColor = SystemColors.Control;
            BtnPen.Location = new Point(15, 25);
            BtnPen.Margin = new Padding(5, 10, 5, 5);
            BtnPen.Name = "BtnPen";
            tableLayoutPanel1.SetRowSpan(BtnPen, 2);
            BtnPen.Size = new Size(30, 40);
            BtnPen.TabIndex = 5;
            BtnPen.Tag = "1";
            BtnPen.UseVisualStyleBackColor = true;
            BtnPen.Click += Btn_Click;
            // 
            // BtnColorDropper
            // 
            BtnColorDropper.BackgroundImage = (Image)resources.GetObject("BtnColorDropper.BackgroundImage");
            BtnColorDropper.BackgroundImageLayout = ImageLayout.Zoom;
            BtnColorDropper.FlatStyle = FlatStyle.Flat;
            BtnColorDropper.ForeColor = SystemColors.Control;
            BtnColorDropper.Location = new Point(147, 25);
            BtnColorDropper.Margin = new Padding(5, 10, 5, 5);
            BtnColorDropper.Name = "BtnColorDropper";
            tableLayoutPanel1.SetRowSpan(BtnColorDropper, 2);
            BtnColorDropper.Size = new Size(30, 40);
            BtnColorDropper.TabIndex = 6;
            BtnColorDropper.Tag = "4";
            BtnColorDropper.UseVisualStyleBackColor = true;
            BtnColorDropper.Click += Btn_Click;
            // 
            // BtnFillColor
            // 
            BtnFillColor.BackgroundImage = (Image)resources.GetObject("BtnFillColor.BackgroundImage");
            BtnFillColor.BackgroundImageLayout = ImageLayout.Zoom;
            BtnFillColor.FlatStyle = FlatStyle.Flat;
            BtnFillColor.ForeColor = SystemColors.Control;
            BtnFillColor.Location = new Point(103, 25);
            BtnFillColor.Margin = new Padding(5, 10, 5, 5);
            BtnFillColor.Name = "BtnFillColor";
            tableLayoutPanel1.SetRowSpan(BtnFillColor, 2);
            BtnFillColor.Size = new Size(30, 40);
            BtnFillColor.TabIndex = 6;
            BtnFillColor.Tag = "3";
            BtnFillColor.UseVisualStyleBackColor = true;
            BtnFillColor.Click += Btn_Click;
            // 
            // BtnCircle
            // 
            BtnCircle.BackgroundImage = (Image)resources.GetObject("BtnCircle.BackgroundImage");
            BtnCircle.BackgroundImageLayout = ImageLayout.Zoom;
            BtnCircle.FlatStyle = FlatStyle.Flat;
            BtnCircle.ForeColor = SystemColors.Control;
            BtnCircle.Location = new Point(323, 25);
            BtnCircle.Margin = new Padding(5, 10, 5, 5);
            BtnCircle.Name = "BtnCircle";
            tableLayoutPanel1.SetRowSpan(BtnCircle, 2);
            BtnCircle.Size = new Size(30, 40);
            BtnCircle.TabIndex = 7;
            BtnCircle.Tag = "7";
            BtnCircle.UseVisualStyleBackColor = true;
            BtnCircle.Click += Btn_Click;
            // 
            // PnlPenWidth
            // 
            PnlPenWidth.Controls.Add(BtnPenWidth1);
            PnlPenWidth.Controls.Add(Largebtn);
            PnlPenWidth.Controls.Add(button9);
            PnlPenWidth.Controls.Add(BtnPenWidth2);
            PnlPenWidth.Location = new Point(381, 15);
            PnlPenWidth.Margin = new Padding(0);
            PnlPenWidth.Name = "PnlPenWidth";
            tableLayoutPanel1.SetRowSpan(PnlPenWidth, 2);
            PnlPenWidth.Size = new Size(57, 58);
            PnlPenWidth.TabIndex = 8;
            // 
            // BtnPenWidth1
            // 
            BtnPenWidth1.BackgroundImage = (Image)resources.GetObject("BtnPenWidth1.BackgroundImage");
            BtnPenWidth1.BackgroundImageLayout = ImageLayout.Zoom;
            BtnPenWidth1.FlatStyle = FlatStyle.Flat;
            BtnPenWidth1.ForeColor = SystemColors.Control;
            BtnPenWidth1.Location = new Point(2, 8);
            BtnPenWidth1.Margin = new Padding(5, 10, 5, 5);
            BtnPenWidth1.Name = "BtnPenWidth1";
            BtnPenWidth1.Size = new Size(50, 15);
            BtnPenWidth1.TabIndex = 9;
            BtnPenWidth1.Tag = "2";
            BtnPenWidth1.UseVisualStyleBackColor = true;
            BtnPenWidth1.Click += BtnPenWidth;
            // 
            // Largebtn
            // 
            Largebtn.BackgroundImage = (Image)resources.GetObject("Largebtn.BackgroundImage");
            Largebtn.BackgroundImageLayout = ImageLayout.Zoom;
            Largebtn.FlatStyle = FlatStyle.Flat;
            Largebtn.ForeColor = SystemColors.Control;
            Largebtn.Location = new Point(5, 38);
            Largebtn.Margin = new Padding(5, 10, 5, 5);
            Largebtn.Name = "Largebtn";
            Largebtn.Size = new Size(50, 15);
            Largebtn.TabIndex = 9;
            Largebtn.Tag = "6";
            Largebtn.UseVisualStyleBackColor = true;
            Largebtn.Click += BtnPenWidth;
            // 
            // button9
            // 
            button9.BackgroundImage = (Image)resources.GetObject("button9.BackgroundImage");
            button9.BackgroundImageLayout = ImageLayout.Zoom;
            button9.FlatStyle = FlatStyle.Flat;
            button9.ForeColor = SystemColors.Control;
            button9.Location = new Point(11, 151);
            button9.Margin = new Padding(5, 10, 5, 5);
            button9.Name = "button9";
            button9.Size = new Size(50, 15);
            button9.TabIndex = 9;
            button9.UseVisualStyleBackColor = true;
            // 
            // BtnPenWidth2
            // 
            BtnPenWidth2.BackgroundImage = (Image)resources.GetObject("BtnPenWidth2.BackgroundImage");
            BtnPenWidth2.BackgroundImageLayout = ImageLayout.Zoom;
            BtnPenWidth2.FlatStyle = FlatStyle.Flat;
            BtnPenWidth2.ForeColor = SystemColors.Control;
            BtnPenWidth2.Location = new Point(5, 23);
            BtnPenWidth2.Margin = new Padding(5, 10, 5, 5);
            BtnPenWidth2.Name = "BtnPenWidth2";
            BtnPenWidth2.Size = new Size(50, 15);
            BtnPenWidth2.TabIndex = 8;
            BtnPenWidth2.Tag = "4";
            BtnPenWidth2.UseVisualStyleBackColor = true;
            BtnPenWidth2.Click += BtnPenWidth;
            // 
            // BtnColorSet
            // 
            BtnColorSet.BackgroundImage = (Image)resources.GetObject("BtnColorSet.BackgroundImage");
            BtnColorSet.BackgroundImageLayout = ImageLayout.Zoom;
            BtnColorSet.FlatStyle = FlatStyle.Flat;
            BtnColorSet.ForeColor = SystemColors.Control;
            BtnColorSet.Location = new Point(736, 25);
            BtnColorSet.Margin = new Padding(5, 10, 5, 5);
            BtnColorSet.Name = "BtnColorSet";
            tableLayoutPanel1.SetRowSpan(BtnColorSet, 2);
            BtnColorSet.Size = new Size(30, 45);
            BtnColorSet.TabIndex = 8;
            BtnColorSet.UseVisualStyleBackColor = true;
            BtnColorSet.Click += BtnColorSet_Click;
            // 
            // Tools
            // 
            tableLayoutPanel1.SetColumnSpan(Tools, 4);
            Tools.Location = new Point(13, 75);
            Tools.Name = "Tools";
            Tools.Size = new Size(170, 23);
            Tools.TabIndex = 23;
            Tools.Text = "Tools";
            Tools.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            tableLayoutPanel1.SetColumnSpan(label1, 4);
            label1.Location = new Point(233, 75);
            label1.Name = "label1";
            label1.Size = new Size(124, 23);
            label1.TabIndex = 24;
            label1.Text = "Shapes";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            tableLayoutPanel1.SetColumnSpan(label2, 4);
            label2.Location = new Point(381, 75);
            label2.Margin = new Padding(0);
            label2.Name = "label2";
            label2.Size = new Size(55, 23);
            label2.TabIndex = 25;
            label2.Text = "Size";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            tableLayoutPanel1.SetColumnSpan(label3, 9);
            label3.Location = new Point(524, 75);
            label3.Margin = new Padding(0);
            label3.Name = "label3";
            label3.Size = new Size(203, 23);
            label3.TabIndex = 24;
            label3.Text = "Colors";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // PnlMain
            // 
            PnlMain.Controls.Add(Pic);
            PnlMain.Dock = DockStyle.Fill;
            PnlMain.Location = new Point(0, 141);
            PnlMain.Name = "PnlMain";
            PnlMain.Size = new Size(800, 309);
            PnlMain.TabIndex = 2;
            // 
            // Pic
            // 
            Pic.BackColor = Color.White;
            Pic.Dock = DockStyle.Fill;
            Pic.Location = new Point(0, 0);
            Pic.Margin = new Padding(0);
            Pic.Name = "Pic";
            Pic.Size = new Size(800, 309);
            Pic.SizeMode = PictureBoxSizeMode.AutoSize;
            Pic.TabIndex = 0;
            Pic.TabStop = false;
            Pic.Paint += Pic_Paint;
            Pic.MouseClick += Pic_MouseClick;
            Pic.MouseDown += Pic_MouseDown;
            Pic.MouseMove += Pic_MouseMove;
            Pic.MouseUp += Pic_MouseUp;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(PnlMain);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)ColorPb).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor20).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor19).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor10).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor9).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor18).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor17).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor8).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor7).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor16).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor15).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor14).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor13).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor12).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor6).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor5).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor4).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor3).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor2).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor11).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnColor1).EndInit();
            PnlPenWidth.ResumeLayout(false);
            PnlMain.ResumeLayout(false);
            PnlMain.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)Pic).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button Exitbtn;
        private Button Minimizebtn;
        private Button Maximizebtn;
        private Button Savebtn;
        private TableLayoutPanel tableLayoutPanel1;
        private Button BtnFillColor;
        private Button BtnPen;
        private Button BtnEraser;
        private Button BtnColorDropper;
        private Button BtnLine;
        private Button BtnRectangle;
        private Button BtnCircle;
        private Panel PnlPenWidth;
        private Button Largebtn;
        private Button button9;
        private Button BtnPenWidth2;
        private Button BtnPenWidth1;
        private Button BtnColorSet;
        private Button ColorPen;
        private Button button15;
        private Button button21;
        private Button btnColor10;
        private Button btnColor9;
        private Button btnColor8;
        private Button btnColor7;
        private Button btnColor6;
        private Button btnColor5;
        private Button btnColor4;
        private Button btnColor3;
        private Button btnColor2;
        private Button btnColor1;
        private Button btnColor11;
        private Button btnColor12;
        private Button btnColor13;
        private Button btnColor14;
        private Button btnColor15;
        private Button btnColor16;
        private Button btnColor17;
        private Button btnColor18;
        private Button btnColor19;
        private Label Tools;
        private Label label1;
        private Label label2;
        private Label label3;
        private Panel PnlMain;
        private PictureBox Pic;
        private Button impBtn;
       
        private PictureBox BtnColor3;
        private PictureBox BtnColor2;
        private PictureBox BtnColor11;
        private PictureBox BtnColor1;
        private PictureBox BtnColor4;
        private PictureBox BtnColor19;
        private PictureBox BtnColor10;
        private PictureBox BtnColor9;
        private PictureBox BtnColor18;
        private PictureBox BtnColor17;
        private PictureBox BtnColor8;
        private PictureBox BtnColor7;
        private PictureBox BtnColor16;
        private PictureBox BtnColor15;
        private PictureBox BtnColor14;
        private PictureBox BtnColor13;
        private PictureBox BtnColor12;
        private PictureBox BtnColor6;
        private PictureBox BtnColor5;
        private PictureBox BtnColor20;
        private PictureBox ColorPb;
    }
}
